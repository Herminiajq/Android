package com.example.mygauth

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FirebaseSignInWithGoogleApp:Application()